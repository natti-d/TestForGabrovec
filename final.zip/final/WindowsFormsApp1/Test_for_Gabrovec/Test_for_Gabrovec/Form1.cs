namespace Test_for_Gabrovec
{
    public partial class home_page : Form
    {
        public home_page()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void igrai_btn_Click(object sender, EventArgs e)
        {
            test_za_gabrovci.badge_collection badges = new test_za_gabrovci.badge_collection();

            this.Hide();
            badges.ShowDialog();
            this.Close();
        }

        private void pomosht_btn_Click(object sender, EventArgs e)
        {
            test_za_gabrovci.Help helps = new test_za_gabrovci.Help();
            helps.ShowDialog();
        }

        private void home_page_Load(object sender, EventArgs e)
        {

        }
    }
}