﻿namespace Test_for_Gabrovec
{
    partial class toplata_staq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(toplata_staq));
            name_panel = new Panel();
            pictureBox10 = new PictureBox();
            nojica_panel = new Panel();
            opashka = new PictureBox();
            nojici = new PictureBox();
            label1 = new Label();
            content_cat_panel = new Panel();
            panel1 = new Panel();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            cherna_kotka = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            name_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            nojica_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)opashka).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nojici).BeginInit();
            content_cat_panel.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cherna_kotka).BeginInit();
            SuspendLayout();
            // 
            // name_panel
            // 
            name_panel.Controls.Add(pictureBox10);
            name_panel.Dock = DockStyle.Top;
            name_panel.Location = new Point(0, 0);
            name_panel.Name = "name_panel";
            name_panel.Size = new Size(1182, 119);
            name_panel.TabIndex = 0;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(200, 0);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(791, 119);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 0;
            pictureBox10.TabStop = false;
            // 
            // nojica_panel
            // 
            nojica_panel.Controls.Add(opashka);
            nojica_panel.Controls.Add(nojici);
            nojica_panel.Controls.Add(label1);
            nojica_panel.Dock = DockStyle.Left;
            nojica_panel.Location = new Point(0, 119);
            nojica_panel.Name = "nojica_panel";
            nojica_panel.Size = new Size(120, 584);
            nojica_panel.TabIndex = 1;
            // 
            // opashka
            // 
            opashka.Location = new Point(32, 177);
            opashka.Name = "opashka";
            opashka.Size = new Size(20, 13);
            opashka.TabIndex = 6;
            opashka.TabStop = false;
            // 
            // nojici
            // 
            nojici.Image = (Image)resources.GetObject("nojici.Image");
            nojici.Location = new Point(32, 211);
            nojici.Name = "nojici";
            nojici.Size = new Size(61, 62);
            nojici.SizeMode = PictureBoxSizeMode.Zoom;
            nojici.TabIndex = 0;
            nojici.TabStop = false;
            // 
            // label1
            // 
            label1.ForeColor = Color.FromArgb(193, 18, 31);
            label1.Location = new Point(57, 8);
            label1.Name = "label1";
            label1.Size = new Size(25, 560);
            label1.TabIndex = 0;
            label1.Text = "|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n|\r\n";
            // 
            // content_cat_panel
            // 
            content_cat_panel.Controls.Add(panel1);
            content_cat_panel.Controls.Add(pictureBox3);
            content_cat_panel.Controls.Add(pictureBox2);
            content_cat_panel.Controls.Add(pictureBox1);
            content_cat_panel.Controls.Add(cherna_kotka);
            content_cat_panel.Dock = DockStyle.Fill;
            content_cat_panel.Location = new Point(120, 119);
            content_cat_panel.Name = "content_cat_panel";
            content_cat_panel.Size = new Size(1062, 584);
            content_cat_panel.TabIndex = 2;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(pictureBox8);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox7);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1062, 584);
            panel1.TabIndex = 4;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.Red;
            pictureBox9.Location = new Point(619, 185);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(20, 3);
            pictureBox9.TabIndex = 5;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.Red;
            pictureBox8.Location = new Point(594, 185);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(20, 3);
            pictureBox8.TabIndex = 4;
            pictureBox8.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Red;
            pictureBox4.Location = new Point(568, 185);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(20, 3);
            pictureBox4.TabIndex = 3;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Red;
            pictureBox5.Location = new Point(541, 185);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(20, 3);
            pictureBox5.TabIndex = 2;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.Red;
            pictureBox6.Location = new Point(513, 185);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(20, 3);
            pictureBox6.TabIndex = 1;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(379, -38);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(621, 667);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 0;
            pictureBox7.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Red;
            pictureBox3.Location = new Point(497, 192);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(20, 3);
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Red;
            pictureBox2.Location = new Point(467, 192);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(20, 3);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Red;
            pictureBox1.Location = new Point(439, 192);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(20, 3);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // cherna_kotka
            // 
            cherna_kotka.Image = (Image)resources.GetObject("cherna_kotka.Image");
            cherna_kotka.Location = new Point(633, -53);
            cherna_kotka.Name = "cherna_kotka";
            cherna_kotka.Size = new Size(621, 667);
            cherna_kotka.SizeMode = PictureBoxSizeMode.Zoom;
            cherna_kotka.TabIndex = 0;
            cherna_kotka.TabStop = false;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // toplata_staq
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 48, 73);
            ClientSize = new Size(1182, 703);
            Controls.Add(content_cat_panel);
            Controls.Add(nojica_panel);
            Controls.Add(name_panel);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "toplata_staq";
            StartPosition = FormStartPosition.WindowsDefaultBounds;
            Text = " ";
            Load += toplata_staq_Load;
            KeyDown += toplata_staq_KeyDown_1;
            name_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            nojica_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)opashka).EndInit();
            ((System.ComponentModel.ISupportInitialize)nojici).EndInit();
            content_cat_panel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)cherna_kotka).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel name_panel;
        private Panel nojica_panel;
        private Panel content_cat_panel;
        private Label label1;
        private PictureBox nojici;
        private PictureBox cherna_kotka;
        private System.Windows.Forms.Timer timer1;
        private Panel panel1;
        private PictureBox pictureBox9;
        private PictureBox pictureBox8;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private PictureBox opashka;
        private PictureBox pictureBox10;
    }
}