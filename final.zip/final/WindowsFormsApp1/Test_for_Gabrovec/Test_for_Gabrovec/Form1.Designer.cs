﻿namespace Test_for_Gabrovec
{
    partial class home_page
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home_page));
            igrai_btn = new Button();
            pomosht_btn = new Button();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // igrai_btn
            // 
            igrai_btn.BackColor = Color.FromArgb(51, 102, 131);
            igrai_btn.BackgroundImageLayout = ImageLayout.None;
            igrai_btn.FlatStyle = FlatStyle.Popup;
            igrai_btn.Font = new Font("Showcard Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point);
            igrai_btn.ForeColor = Color.FromArgb(250, 221, 158);
            igrai_btn.Location = new Point(508, 337);
            igrai_btn.Name = "igrai_btn";
            igrai_btn.Size = new Size(180, 81);
            igrai_btn.TabIndex = 2;
            igrai_btn.Text = "Играй";
            igrai_btn.UseVisualStyleBackColor = false;
            igrai_btn.Click += igrai_btn_Click;
            // 
            // pomosht_btn
            // 
            pomosht_btn.BackColor = Color.FromArgb(51, 102, 131);
            pomosht_btn.BackgroundImageLayout = ImageLayout.None;
            pomosht_btn.FlatStyle = FlatStyle.Popup;
            pomosht_btn.Font = new Font("Showcard Gothic", 24F, FontStyle.Bold, GraphicsUnit.Point);
            pomosht_btn.ForeColor = Color.FromArgb(250, 221, 158);
            pomosht_btn.Location = new Point(508, 434);
            pomosht_btn.Name = "pomosht_btn";
            pomosht_btn.Size = new Size(180, 81);
            pomosht_btn.TabIndex = 3;
            pomosht_btn.Text = "Помощ";
            pomosht_btn.UseVisualStyleBackColor = false;
            pomosht_btn.Click += pomosht_btn_Click;
            // 
            // panel1
            // 
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1182, 119);
            panel1.TabIndex = 5;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1164, 183);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // home_page
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 48, 73);
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1182, 703);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            Controls.Add(pomosht_btn);
            Controls.Add(igrai_btn);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "home_page";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Тест за скъперници";
            Load += home_page_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button igrai_btn;
        private Button pomosht_btn;
        private Panel panel1;
        private PictureBox pictureBox2;
    }
}