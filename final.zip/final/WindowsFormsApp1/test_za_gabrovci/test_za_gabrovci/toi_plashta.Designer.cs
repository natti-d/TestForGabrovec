﻿namespace test_za_gabrovci
{
    partial class toi_plashta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.name_panel = new System.Windows.Forms.Panel();
            this.menu_timer_panel = new System.Windows.Forms.Panel();
            this.menu_count_items_lbl = new System.Windows.Forms.Label();
            this.crazy_time_lbl = new System.Windows.Forms.Label();
            this.menu_category1 = new System.Windows.Forms.Label();
            this.menu_item1 = new System.Windows.Forms.Label();
            this.menu_item2 = new System.Windows.Forms.Label();
            this.menu_item3 = new System.Windows.Forms.Label();
            this.menu_item4 = new System.Windows.Forms.Label();
            this.menu_item5 = new System.Windows.Forms.Label();
            this.menu_item6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.menu_item7 = new System.Windows.Forms.Label();
            this.menu_category3 = new System.Windows.Forms.Label();
            this.menu_item8 = new System.Windows.Forms.Label();
            this.menu_item9 = new System.Windows.Forms.Label();
            this.menu_category4 = new System.Windows.Forms.Label();
            this.menu_item10 = new System.Windows.Forms.Label();
            this.menu_item11 = new System.Windows.Forms.Label();
            this.menu_item12 = new System.Windows.Forms.Label();
            this.item_price1 = new System.Windows.Forms.Label();
            this.item_price2 = new System.Windows.Forms.Label();
            this.item_price3 = new System.Windows.Forms.Label();
            this.item_price4 = new System.Windows.Forms.Label();
            this.item_price5 = new System.Windows.Forms.Label();
            this.item_price6 = new System.Windows.Forms.Label();
            this.item_price7 = new System.Windows.Forms.Label();
            this.item_price8 = new System.Windows.Forms.Label();
            this.item_price9 = new System.Windows.Forms.Label();
            this.item_price10 = new System.Windows.Forms.Label();
            this.item_price11 = new System.Windows.Forms.Label();
            this.item_price12 = new System.Windows.Forms.Label();
            this.menu_timer = new System.Windows.Forms.Timer(this.components);
            this.chercked12 = new System.Windows.Forms.PictureBox();
            this.chercked11 = new System.Windows.Forms.PictureBox();
            this.chercked10 = new System.Windows.Forms.PictureBox();
            this.chercked9 = new System.Windows.Forms.PictureBox();
            this.chercked8 = new System.Windows.Forms.PictureBox();
            this.chercked7 = new System.Windows.Forms.PictureBox();
            this.chercked6 = new System.Windows.Forms.PictureBox();
            this.chercked5 = new System.Windows.Forms.PictureBox();
            this.chercked4 = new System.Windows.Forms.PictureBox();
            this.chercked3 = new System.Windows.Forms.PictureBox();
            this.chercked2 = new System.Windows.Forms.PictureBox();
            this.chercked1 = new System.Windows.Forms.PictureBox();
            this.menu_picbox = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.info_box = new System.Windows.Forms.PictureBox();
            this.help_btn = new System.Windows.Forms.PictureBox();
            this.name_panel.SuspendLayout();
            this.menu_timer_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chercked12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menu_picbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.info_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.help_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // name_panel
            // 
            this.name_panel.Controls.Add(this.pictureBox1);
            this.name_panel.Controls.Add(this.info_box);
            this.name_panel.Controls.Add(this.help_btn);
            this.name_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.name_panel.Location = new System.Drawing.Point(0, 0);
            this.name_panel.Name = "name_panel";
            this.name_panel.Size = new System.Drawing.Size(1182, 119);
            this.name_panel.TabIndex = 2;
            // 
            // menu_timer_panel
            // 
            this.menu_timer_panel.Controls.Add(this.menu_count_items_lbl);
            this.menu_timer_panel.Controls.Add(this.crazy_time_lbl);
            this.menu_timer_panel.Dock = System.Windows.Forms.DockStyle.Right;
            this.menu_timer_panel.Location = new System.Drawing.Point(990, 119);
            this.menu_timer_panel.Name = "menu_timer_panel";
            this.menu_timer_panel.Size = new System.Drawing.Size(192, 584);
            this.menu_timer_panel.TabIndex = 4;
            // 
            // menu_count_items_lbl
            // 
            this.menu_count_items_lbl.AutoSize = true;
            this.menu_count_items_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_count_items_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(221)))), ((int)(((byte)(158)))));
            this.menu_count_items_lbl.Location = new System.Drawing.Point(69, 98);
            this.menu_count_items_lbl.Name = "menu_count_items_lbl";
            this.menu_count_items_lbl.Size = new System.Drawing.Size(64, 39);
            this.menu_count_items_lbl.TabIndex = 1;
            this.menu_count_items_lbl.Text = "0/3";
            this.menu_count_items_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // crazy_time_lbl
            // 
            this.crazy_time_lbl.AutoSize = true;
            this.crazy_time_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crazy_time_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(221)))), ((int)(((byte)(158)))));
            this.crazy_time_lbl.Location = new System.Drawing.Point(46, 20);
            this.crazy_time_lbl.Name = "crazy_time_lbl";
            this.crazy_time_lbl.Size = new System.Drawing.Size(102, 39);
            this.crazy_time_lbl.TabIndex = 0;
            this.crazy_time_lbl.Text = "00:30";
            // 
            // menu_category1
            // 
            this.menu_category1.AutoSize = true;
            this.menu_category1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_category1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_category1.Location = new System.Drawing.Point(260, 169);
            this.menu_category1.Name = "menu_category1";
            this.menu_category1.Size = new System.Drawing.Size(128, 36);
            this.menu_category1.TabIndex = 5;
            this.menu_category1.Text = "Салати";
            // 
            // menu_item1
            // 
            this.menu_item1.AutoSize = true;
            this.menu_item1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item1.Location = new System.Drawing.Point(138, 227);
            this.menu_item1.Name = "menu_item1";
            this.menu_item1.Size = new System.Drawing.Size(210, 29);
            this.menu_item1.TabIndex = 6;
            this.menu_item1.Text = "Салата с ябълки";
            this.menu_item1.Click += new System.EventHandler(this.item_price1_Click);
            // 
            // menu_item2
            // 
            this.menu_item2.AutoSize = true;
            this.menu_item2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item2.Location = new System.Drawing.Point(140, 283);
            this.menu_item2.Name = "menu_item2";
            this.menu_item2.Size = new System.Drawing.Size(234, 29);
            this.menu_item2.TabIndex = 7;
            this.menu_item2.Text = "Салата от орхидеи";
            this.menu_item2.Click += new System.EventHandler(this.menu_item2_Click);
            // 
            // menu_item3
            // 
            this.menu_item3.AutoSize = true;
            this.menu_item3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item3.Location = new System.Drawing.Point(140, 342);
            this.menu_item3.Name = "menu_item3";
            this.menu_item3.Size = new System.Drawing.Size(202, 29);
            this.menu_item3.TabIndex = 8;
            this.menu_item3.Text = "Пясъчна салата";
            this.menu_item3.Click += new System.EventHandler(this.menu_item3_Click);
            // 
            // menu_item4
            // 
            this.menu_item4.AutoSize = true;
            this.menu_item4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item4.Location = new System.Drawing.Point(140, 464);
            this.menu_item4.Name = "menu_item4";
            this.menu_item4.Size = new System.Drawing.Size(262, 29);
            this.menu_item4.TabIndex = 10;
            this.menu_item4.Text = "Картофки с шоколад";
            this.menu_item4.Click += new System.EventHandler(this.menu_item4_Click);
            // 
            // menu_item5
            // 
            this.menu_item5.AutoSize = true;
            this.menu_item5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item5.Location = new System.Drawing.Point(140, 528);
            this.menu_item5.Name = "menu_item5";
            this.menu_item5.Size = new System.Drawing.Size(212, 29);
            this.menu_item5.TabIndex = 11;
            this.menu_item5.Text = "Лилави фъстъци";
            this.menu_item5.Click += new System.EventHandler(this.menu_item5_Click);
            // 
            // menu_item6
            // 
            this.menu_item6.AutoSize = true;
            this.menu_item6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item6.Location = new System.Drawing.Point(140, 592);
            this.menu_item6.Name = "menu_item6";
            this.menu_item6.Size = new System.Drawing.Size(258, 29);
            this.menu_item6.TabIndex = 12;
            this.menu_item6.Text = "Моркови с майонеза";
            this.menu_item6.Click += new System.EventHandler(this.menu_item6_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(231, 401);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 36);
            this.label4.TabIndex = 13;
            this.label4.Text = "Предястия";
            // 
            // menu_item7
            // 
            this.menu_item7.AutoSize = true;
            this.menu_item7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item7.Location = new System.Drawing.Point(508, 227);
            this.menu_item7.Name = "menu_item7";
            this.menu_item7.Size = new System.Drawing.Size(226, 29);
            this.menu_item7.TabIndex = 14;
            this.menu_item7.Text = "Ориз със здравец";
            this.menu_item7.Click += new System.EventHandler(this.menu_item7_Click);
            // 
            // menu_category3
            // 
            this.menu_category3.AutoSize = true;
            this.menu_category3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_category3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_category3.Location = new System.Drawing.Point(577, 169);
            this.menu_category3.Name = "menu_category3";
            this.menu_category3.Size = new System.Drawing.Size(205, 36);
            this.menu_category3.TabIndex = 15;
            this.menu_category3.Text = "Топли ястия";
            // 
            // menu_item8
            // 
            this.menu_item8.AutoSize = true;
            this.menu_item8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item8.Location = new System.Drawing.Point(508, 283);
            this.menu_item8.Name = "menu_item8";
            this.menu_item8.Size = new System.Drawing.Size(183, 29);
            this.menu_item8.TabIndex = 16;
            this.menu_item8.Text = "Пиле от мента";
            this.menu_item8.Click += new System.EventHandler(this.menu_item8_Click);
            // 
            // menu_item9
            // 
            this.menu_item9.AutoSize = true;
            this.menu_item9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item9.Location = new System.Drawing.Point(508, 342);
            this.menu_item9.Name = "menu_item9";
            this.menu_item9.Size = new System.Drawing.Size(166, 29);
            this.menu_item9.TabIndex = 17;
            this.menu_item9.Text = "Медена супа";
            this.menu_item9.Click += new System.EventHandler(this.menu_item9_Click);
            // 
            // menu_category4
            // 
            this.menu_category4.AutoSize = true;
            this.menu_category4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_category4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_category4.Location = new System.Drawing.Point(610, 401);
            this.menu_category4.Name = "menu_category4";
            this.menu_category4.Size = new System.Drawing.Size(144, 36);
            this.menu_category4.TabIndex = 18;
            this.menu_category4.Text = "Напитки";
            // 
            // menu_item10
            // 
            this.menu_item10.AutoSize = true;
            this.menu_item10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item10.Location = new System.Drawing.Point(508, 464);
            this.menu_item10.Name = "menu_item10";
            this.menu_item10.Size = new System.Drawing.Size(152, 29);
            this.menu_item10.TabIndex = 19;
            this.menu_item10.Text = "Сок от рози";
            this.menu_item10.Click += new System.EventHandler(this.menu_item10_Click);
            // 
            // menu_item11
            // 
            this.menu_item11.AutoSize = true;
            this.menu_item11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item11.Location = new System.Drawing.Point(508, 528);
            this.menu_item11.Name = "menu_item11";
            this.menu_item11.Size = new System.Drawing.Size(181, 29);
            this.menu_item11.TabIndex = 20;
            this.menu_item11.Text = "Водка от лале";
            this.menu_item11.Click += new System.EventHandler(this.menu_item11_Click);
            // 
            // menu_item12
            // 
            this.menu_item12.AutoSize = true;
            this.menu_item12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.menu_item12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu_item12.Location = new System.Drawing.Point(508, 592);
            this.menu_item12.Name = "menu_item12";
            this.menu_item12.Size = new System.Drawing.Size(166, 29);
            this.menu_item12.TabIndex = 21;
            this.menu_item12.Text = "Сода с кости";
            this.menu_item12.Click += new System.EventHandler(this.menu_item12_Click);
            // 
            // item_price1
            // 
            this.item_price1.AutoSize = true;
            this.item_price1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price1.Location = new System.Drawing.Point(438, 227);
            this.item_price1.Name = "item_price1";
            this.item_price1.Size = new System.Drawing.Size(62, 29);
            this.item_price1.TabIndex = 22;
            this.item_price1.Text = "0,00";
            this.item_price1.Click += new System.EventHandler(this.item_price1_Click);
            // 
            // item_price2
            // 
            this.item_price2.AutoSize = true;
            this.item_price2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price2.Location = new System.Drawing.Point(438, 283);
            this.item_price2.Name = "item_price2";
            this.item_price2.Size = new System.Drawing.Size(62, 29);
            this.item_price2.TabIndex = 23;
            this.item_price2.Text = "0,00";
            this.item_price2.Click += new System.EventHandler(this.menu_item2_Click);
            // 
            // item_price3
            // 
            this.item_price3.AutoSize = true;
            this.item_price3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price3.Location = new System.Drawing.Point(438, 342);
            this.item_price3.Name = "item_price3";
            this.item_price3.Size = new System.Drawing.Size(62, 29);
            this.item_price3.TabIndex = 24;
            this.item_price3.Text = "0,00";
            this.item_price3.Click += new System.EventHandler(this.menu_item3_Click);
            // 
            // item_price4
            // 
            this.item_price4.AutoSize = true;
            this.item_price4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price4.Location = new System.Drawing.Point(438, 464);
            this.item_price4.Name = "item_price4";
            this.item_price4.Size = new System.Drawing.Size(62, 29);
            this.item_price4.TabIndex = 25;
            this.item_price4.Text = "0,00";
            this.item_price4.Click += new System.EventHandler(this.menu_item4_Click);
            // 
            // item_price5
            // 
            this.item_price5.AutoSize = true;
            this.item_price5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price5.Location = new System.Drawing.Point(438, 528);
            this.item_price5.Name = "item_price5";
            this.item_price5.Size = new System.Drawing.Size(62, 29);
            this.item_price5.TabIndex = 26;
            this.item_price5.Text = "0,00";
            this.item_price5.Click += new System.EventHandler(this.menu_item5_Click);
            // 
            // item_price6
            // 
            this.item_price6.AutoSize = true;
            this.item_price6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price6.Location = new System.Drawing.Point(438, 592);
            this.item_price6.Name = "item_price6";
            this.item_price6.Size = new System.Drawing.Size(62, 29);
            this.item_price6.TabIndex = 27;
            this.item_price6.Text = "0,00";
            this.item_price6.Click += new System.EventHandler(this.menu_item6_Click);
            // 
            // item_price7
            // 
            this.item_price7.AutoSize = true;
            this.item_price7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price7.Location = new System.Drawing.Point(808, 227);
            this.item_price7.Name = "item_price7";
            this.item_price7.Size = new System.Drawing.Size(62, 29);
            this.item_price7.TabIndex = 28;
            this.item_price7.Text = "0,00";
            this.item_price7.Click += new System.EventHandler(this.menu_item7_Click);
            // 
            // item_price8
            // 
            this.item_price8.AutoSize = true;
            this.item_price8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price8.Location = new System.Drawing.Point(808, 283);
            this.item_price8.Name = "item_price8";
            this.item_price8.Size = new System.Drawing.Size(62, 29);
            this.item_price8.TabIndex = 29;
            this.item_price8.Text = "0,00";
            this.item_price8.Click += new System.EventHandler(this.menu_item8_Click);
            // 
            // item_price9
            // 
            this.item_price9.AutoSize = true;
            this.item_price9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price9.Location = new System.Drawing.Point(808, 342);
            this.item_price9.Name = "item_price9";
            this.item_price9.Size = new System.Drawing.Size(62, 29);
            this.item_price9.TabIndex = 30;
            this.item_price9.Text = "0,00";
            this.item_price9.Click += new System.EventHandler(this.menu_item9_Click);
            // 
            // item_price10
            // 
            this.item_price10.AutoSize = true;
            this.item_price10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price10.Location = new System.Drawing.Point(808, 464);
            this.item_price10.Name = "item_price10";
            this.item_price10.Size = new System.Drawing.Size(62, 29);
            this.item_price10.TabIndex = 31;
            this.item_price10.Text = "0,00";
            this.item_price10.Click += new System.EventHandler(this.menu_item10_Click);
            // 
            // item_price11
            // 
            this.item_price11.AutoSize = true;
            this.item_price11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price11.Location = new System.Drawing.Point(808, 528);
            this.item_price11.Name = "item_price11";
            this.item_price11.Size = new System.Drawing.Size(62, 29);
            this.item_price11.TabIndex = 32;
            this.item_price11.Text = "0,00";
            this.item_price11.Click += new System.EventHandler(this.menu_item11_Click);
            // 
            // item_price12
            // 
            this.item_price12.AutoSize = true;
            this.item_price12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.item_price12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_price12.Location = new System.Drawing.Point(808, 592);
            this.item_price12.Name = "item_price12";
            this.item_price12.Size = new System.Drawing.Size(62, 29);
            this.item_price12.TabIndex = 33;
            this.item_price12.Text = "0,00";
            this.item_price12.Click += new System.EventHandler(this.menu_item12_Click);
            // 
            // menu_timer
            // 
            this.menu_timer.Interval = 800;
            this.menu_timer.Tick += new System.EventHandler(this.menu_timer_Tick);
            // 
            // chercked12
            // 
            this.chercked12.Location = new System.Drawing.Point(513, 608);
            this.chercked12.Name = "chercked12";
            this.chercked12.Size = new System.Drawing.Size(346, 3);
            this.chercked12.TabIndex = 45;
            this.chercked12.TabStop = false;
            this.chercked12.Visible = false;
            // 
            // chercked11
            // 
            this.chercked11.Location = new System.Drawing.Point(513, 544);
            this.chercked11.Name = "chercked11";
            this.chercked11.Size = new System.Drawing.Size(346, 3);
            this.chercked11.TabIndex = 44;
            this.chercked11.TabStop = false;
            this.chercked11.Visible = false;
            // 
            // chercked10
            // 
            this.chercked10.Location = new System.Drawing.Point(513, 480);
            this.chercked10.Name = "chercked10";
            this.chercked10.Size = new System.Drawing.Size(346, 3);
            this.chercked10.TabIndex = 43;
            this.chercked10.TabStop = false;
            this.chercked10.Visible = false;
            // 
            // chercked9
            // 
            this.chercked9.Location = new System.Drawing.Point(513, 358);
            this.chercked9.Name = "chercked9";
            this.chercked9.Size = new System.Drawing.Size(346, 3);
            this.chercked9.TabIndex = 42;
            this.chercked9.TabStop = false;
            this.chercked9.Visible = false;
            // 
            // chercked8
            // 
            this.chercked8.Location = new System.Drawing.Point(513, 299);
            this.chercked8.Name = "chercked8";
            this.chercked8.Size = new System.Drawing.Size(346, 3);
            this.chercked8.TabIndex = 41;
            this.chercked8.TabStop = false;
            this.chercked8.Visible = false;
            // 
            // chercked7
            // 
            this.chercked7.Location = new System.Drawing.Point(513, 242);
            this.chercked7.Name = "chercked7";
            this.chercked7.Size = new System.Drawing.Size(346, 3);
            this.chercked7.TabIndex = 40;
            this.chercked7.TabStop = false;
            this.chercked7.Visible = false;
            // 
            // chercked6
            // 
            this.chercked6.Location = new System.Drawing.Point(143, 608);
            this.chercked6.Name = "chercked6";
            this.chercked6.Size = new System.Drawing.Size(346, 3);
            this.chercked6.TabIndex = 39;
            this.chercked6.TabStop = false;
            this.chercked6.Visible = false;
            // 
            // chercked5
            // 
            this.chercked5.Location = new System.Drawing.Point(143, 544);
            this.chercked5.Name = "chercked5";
            this.chercked5.Size = new System.Drawing.Size(346, 3);
            this.chercked5.TabIndex = 38;
            this.chercked5.TabStop = false;
            this.chercked5.Visible = false;
            // 
            // chercked4
            // 
            this.chercked4.Location = new System.Drawing.Point(143, 480);
            this.chercked4.Name = "chercked4";
            this.chercked4.Size = new System.Drawing.Size(346, 3);
            this.chercked4.TabIndex = 37;
            this.chercked4.TabStop = false;
            this.chercked4.Visible = false;
            // 
            // chercked3
            // 
            this.chercked3.Location = new System.Drawing.Point(143, 358);
            this.chercked3.Name = "chercked3";
            this.chercked3.Size = new System.Drawing.Size(346, 3);
            this.chercked3.TabIndex = 36;
            this.chercked3.TabStop = false;
            this.chercked3.Visible = false;
            // 
            // chercked2
            // 
            this.chercked2.Location = new System.Drawing.Point(143, 299);
            this.chercked2.Name = "chercked2";
            this.chercked2.Size = new System.Drawing.Size(346, 3);
            this.chercked2.TabIndex = 35;
            this.chercked2.TabStop = false;
            this.chercked2.Visible = false;
            // 
            // chercked1
            // 
            this.chercked1.Location = new System.Drawing.Point(143, 242);
            this.chercked1.Name = "chercked1";
            this.chercked1.Size = new System.Drawing.Size(346, 3);
            this.chercked1.TabIndex = 34;
            this.chercked1.TabStop = false;
            this.chercked1.Visible = false;
            // 
            // menu_picbox
            // 
            this.menu_picbox.Image = global::test_za_gabrovci.Properties.Resources.menu;
            this.menu_picbox.Location = new System.Drawing.Point(-26, 127);
            this.menu_picbox.Name = "menu_picbox";
            this.menu_picbox.Size = new System.Drawing.Size(1056, 566);
            this.menu_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.menu_picbox.TabIndex = 3;
            this.menu_picbox.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::test_za_gabrovci.Properties.Resources._418111385_2087731028274814_4191187644128955929_n;
            this.pictureBox1.Location = new System.Drawing.Point(186, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(673, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // info_box
            // 
            this.info_box.BackColor = System.Drawing.Color.Transparent;
            this.info_box.Image = global::test_za_gabrovci.Properties.Resources.info;
            this.info_box.Location = new System.Drawing.Point(978, 12);
            this.info_box.Name = "info_box";
            this.info_box.Size = new System.Drawing.Size(93, 93);
            this.info_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.info_box.TabIndex = 7;
            this.info_box.TabStop = false;
            this.info_box.Click += new System.EventHandler(this.info_box_Click);
            // 
            // help_btn
            // 
            this.help_btn.BackColor = System.Drawing.Color.Transparent;
            this.help_btn.Image = global::test_za_gabrovci.Properties.Resources.help_btn_img;
            this.help_btn.Location = new System.Drawing.Point(1077, 12);
            this.help_btn.Name = "help_btn";
            this.help_btn.Size = new System.Drawing.Size(93, 93);
            this.help_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.help_btn.TabIndex = 5;
            this.help_btn.TabStop = false;
            this.help_btn.Click += new System.EventHandler(this.help_btn_Click);
            // 
            // toi_plashta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1182, 703);
            this.Controls.Add(this.chercked12);
            this.Controls.Add(this.chercked11);
            this.Controls.Add(this.chercked10);
            this.Controls.Add(this.chercked9);
            this.Controls.Add(this.chercked8);
            this.Controls.Add(this.chercked7);
            this.Controls.Add(this.chercked6);
            this.Controls.Add(this.chercked5);
            this.Controls.Add(this.chercked4);
            this.Controls.Add(this.chercked3);
            this.Controls.Add(this.chercked2);
            this.Controls.Add(this.chercked1);
            this.Controls.Add(this.item_price12);
            this.Controls.Add(this.item_price11);
            this.Controls.Add(this.item_price10);
            this.Controls.Add(this.item_price9);
            this.Controls.Add(this.item_price8);
            this.Controls.Add(this.item_price7);
            this.Controls.Add(this.item_price6);
            this.Controls.Add(this.item_price5);
            this.Controls.Add(this.item_price4);
            this.Controls.Add(this.item_price3);
            this.Controls.Add(this.item_price2);
            this.Controls.Add(this.item_price1);
            this.Controls.Add(this.menu_item12);
            this.Controls.Add(this.menu_item11);
            this.Controls.Add(this.menu_item10);
            this.Controls.Add(this.menu_category4);
            this.Controls.Add(this.menu_item9);
            this.Controls.Add(this.menu_item8);
            this.Controls.Add(this.menu_category3);
            this.Controls.Add(this.menu_item7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.menu_item6);
            this.Controls.Add(this.menu_item5);
            this.Controls.Add(this.menu_item4);
            this.Controls.Add(this.menu_item3);
            this.Controls.Add(this.menu_item2);
            this.Controls.Add(this.menu_item1);
            this.Controls.Add(this.menu_category1);
            this.Controls.Add(this.menu_timer_panel);
            this.Controls.Add(this.menu_picbox);
            this.Controls.Add(this.name_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "toi_plashta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Той плаща";
            this.Load += new System.EventHandler(this.toi_plashta_Load);
            this.name_panel.ResumeLayout(false);
            this.menu_timer_panel.ResumeLayout(false);
            this.menu_timer_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chercked12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chercked1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menu_picbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.info_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.help_btn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel name_panel;
        private System.Windows.Forms.PictureBox help_btn;
        private System.Windows.Forms.PictureBox info_box;
        private System.Windows.Forms.PictureBox menu_picbox;
        private System.Windows.Forms.Panel menu_timer_panel;
        private System.Windows.Forms.Label menu_count_items_lbl;
        private System.Windows.Forms.Label crazy_time_lbl;
        private System.Windows.Forms.Label menu_category1;
        private System.Windows.Forms.Label menu_item1;
        private System.Windows.Forms.Label menu_item2;
        private System.Windows.Forms.Label menu_item3;
        private System.Windows.Forms.Label menu_item4;
        private System.Windows.Forms.Label menu_item5;
        private System.Windows.Forms.Label menu_item6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label menu_item7;
        private System.Windows.Forms.Label menu_category3;
        private System.Windows.Forms.Label menu_item8;
        private System.Windows.Forms.Label menu_item9;
        private System.Windows.Forms.Label menu_category4;
        private System.Windows.Forms.Label menu_item10;
        private System.Windows.Forms.Label menu_item11;
        private System.Windows.Forms.Label menu_item12;
        private System.Windows.Forms.Label item_price1;
        private System.Windows.Forms.Label item_price2;
        private System.Windows.Forms.Label item_price3;
        private System.Windows.Forms.Label item_price4;
        private System.Windows.Forms.Label item_price5;
        private System.Windows.Forms.Label item_price6;
        private System.Windows.Forms.Label item_price7;
        private System.Windows.Forms.Label item_price8;
        private System.Windows.Forms.Label item_price9;
        private System.Windows.Forms.Label item_price10;
        private System.Windows.Forms.Label item_price11;
        private System.Windows.Forms.Label item_price12;
        private System.Windows.Forms.Timer menu_timer;
        private System.Windows.Forms.PictureBox chercked1;
        private System.Windows.Forms.PictureBox chercked2;
        private System.Windows.Forms.PictureBox chercked3;
        private System.Windows.Forms.PictureBox chercked4;
        private System.Windows.Forms.PictureBox chercked5;
        private System.Windows.Forms.PictureBox chercked6;
        private System.Windows.Forms.PictureBox chercked7;
        private System.Windows.Forms.PictureBox chercked8;
        private System.Windows.Forms.PictureBox chercked9;
        private System.Windows.Forms.PictureBox chercked10;
        private System.Windows.Forms.PictureBox chercked11;
        private System.Windows.Forms.PictureBox chercked12;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}