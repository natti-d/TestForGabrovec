﻿namespace test_za_gabrovci
{
    partial class denqt_se_poznava_ot_sutrinta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.name_panel = new System.Windows.Forms.Panel();
            this.gevrek_broika_panel = new System.Windows.Forms.Panel();
            this.gevrek_count_txtbox = new System.Windows.Forms.TextBox();
            this.gevrek_count_lbl = new System.Windows.Forms.Label();
            this.crazy_time_lbl = new System.Windows.Forms.Label();
            this.gevrek_timer = new System.Windows.Forms.Timer(this.components);
            this.red_big_btn = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.info_box = new System.Windows.Forms.PictureBox();
            this.help_btn = new System.Windows.Forms.PictureBox();
            this.name_panel.SuspendLayout();
            this.gevrek_broika_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.red_big_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.info_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.help_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // name_panel
            // 
            this.name_panel.Controls.Add(this.pictureBox1);
            this.name_panel.Controls.Add(this.info_box);
            this.name_panel.Controls.Add(this.help_btn);
            this.name_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.name_panel.Location = new System.Drawing.Point(0, 0);
            this.name_panel.Name = "name_panel";
            this.name_panel.Size = new System.Drawing.Size(1182, 178);
            this.name_panel.TabIndex = 2;
            // 
            // gevrek_broika_panel
            // 
            this.gevrek_broika_panel.Controls.Add(this.gevrek_count_txtbox);
            this.gevrek_broika_panel.Controls.Add(this.gevrek_count_lbl);
            this.gevrek_broika_panel.Controls.Add(this.red_big_btn);
            this.gevrek_broika_panel.Controls.Add(this.crazy_time_lbl);
            this.gevrek_broika_panel.Dock = System.Windows.Forms.DockStyle.Right;
            this.gevrek_broika_panel.Location = new System.Drawing.Point(990, 178);
            this.gevrek_broika_panel.Name = "gevrek_broika_panel";
            this.gevrek_broika_panel.Size = new System.Drawing.Size(192, 525);
            this.gevrek_broika_panel.TabIndex = 3;
            // 
            // gevrek_count_txtbox
            // 
            this.gevrek_count_txtbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.gevrek_count_txtbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gevrek_count_txtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gevrek_count_txtbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.gevrek_count_txtbox.Location = new System.Drawing.Point(28, 179);
            this.gevrek_count_txtbox.Multiline = true;
            this.gevrek_count_txtbox.Name = "gevrek_count_txtbox";
            this.gevrek_count_txtbox.ReadOnly = true;
            this.gevrek_count_txtbox.Size = new System.Drawing.Size(153, 38);
            this.gevrek_count_txtbox.TabIndex = 3;
            this.gevrek_count_txtbox.Text = "0";
            this.gevrek_count_txtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gevrek_count_lbl
            // 
            this.gevrek_count_lbl.AutoSize = true;
            this.gevrek_count_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gevrek_count_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(221)))), ((int)(((byte)(158)))));
            this.gevrek_count_lbl.Location = new System.Drawing.Point(23, 86);
            this.gevrek_count_lbl.Name = "gevrek_count_lbl";
            this.gevrek_count_lbl.Size = new System.Drawing.Size(153, 78);
            this.gevrek_count_lbl.TabIndex = 2;
            this.gevrek_count_lbl.Text = "Брой\r\nгевреци:";
            this.gevrek_count_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // crazy_time_lbl
            // 
            this.crazy_time_lbl.AutoSize = true;
            this.crazy_time_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crazy_time_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(221)))), ((int)(((byte)(158)))));
            this.crazy_time_lbl.Location = new System.Drawing.Point(46, 20);
            this.crazy_time_lbl.Name = "crazy_time_lbl";
            this.crazy_time_lbl.Size = new System.Drawing.Size(102, 39);
            this.crazy_time_lbl.TabIndex = 0;
            this.crazy_time_lbl.Text = "00:30";
            // 
            // gevrek_timer
            // 
            this.gevrek_timer.Interval = 800;
            this.gevrek_timer.Tick += new System.EventHandler(this.gevrek_time_Tick);
            // 
            // red_big_btn
            // 
            this.red_big_btn.Image = global::test_za_gabrovci.Properties.Resources.red_btn;
            this.red_big_btn.Location = new System.Drawing.Point(3, 392);
            this.red_big_btn.Name = "red_big_btn";
            this.red_big_btn.Size = new System.Drawing.Size(192, 192);
            this.red_big_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.red_big_btn.TabIndex = 1;
            this.red_big_btn.TabStop = false;
            this.red_big_btn.Click += new System.EventHandler(this.red_big_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::test_za_gabrovci.Properties.Resources._417722134_914184933497099_8496871845796908396_n;
            this.pictureBox1.Location = new System.Drawing.Point(272, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(700, 157);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // info_box
            // 
            this.info_box.BackColor = System.Drawing.Color.Transparent;
            this.info_box.Image = global::test_za_gabrovci.Properties.Resources.info;
            this.info_box.Location = new System.Drawing.Point(978, 12);
            this.info_box.Name = "info_box";
            this.info_box.Size = new System.Drawing.Size(93, 93);
            this.info_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.info_box.TabIndex = 8;
            this.info_box.TabStop = false;
            this.info_box.Click += new System.EventHandler(this.info_box_Click);
            // 
            // help_btn
            // 
            this.help_btn.BackColor = System.Drawing.Color.Transparent;
            this.help_btn.Image = global::test_za_gabrovci.Properties.Resources.help_btn_img1;
            this.help_btn.Location = new System.Drawing.Point(1077, 12);
            this.help_btn.Name = "help_btn";
            this.help_btn.Size = new System.Drawing.Size(93, 93);
            this.help_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.help_btn.TabIndex = 5;
            this.help_btn.TabStop = false;
            this.help_btn.Click += new System.EventHandler(this.help_btn_Click);
            // 
            // denqt_se_poznava_ot_sutrinta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1182, 703);
            this.Controls.Add(this.gevrek_broika_panel);
            this.Controls.Add(this.name_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "denqt_se_poznava_ot_sutrinta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Денят се познава от сутринта";
            this.Load += new System.EventHandler(this.denqt_se_poznava_ot_sutrinta_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.denqt_se_poznava_ot_sutrinta_KeyDown);
            this.name_panel.ResumeLayout(false);
            this.gevrek_broika_panel.ResumeLayout(false);
            this.gevrek_broika_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.red_big_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.info_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.help_btn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel name_panel;
        private System.Windows.Forms.PictureBox help_btn;
        private System.Windows.Forms.Panel gevrek_broika_panel;
        private System.Windows.Forms.Label crazy_time_lbl;
        private System.Windows.Forms.PictureBox red_big_btn;
        private System.Windows.Forms.TextBox gevrek_count_txtbox;
        private System.Windows.Forms.Label gevrek_count_lbl;
        private System.Windows.Forms.Timer gevrek_timer;
        private System.Windows.Forms.PictureBox info_box;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}