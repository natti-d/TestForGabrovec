﻿namespace test_za_gabrovci
{
    partial class badge_collection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.badge_lbl = new System.Windows.Forms.Label();
            this.name_panel = new System.Windows.Forms.Panel();
            this.content_badge_panel = new System.Windows.Forms.Panel();
            this.game6 = new System.Windows.Forms.PictureBox();
            this.game5 = new System.Windows.Forms.PictureBox();
            this.game4 = new System.Windows.Forms.PictureBox();
            this.toi_plashta_picbox = new System.Windows.Forms.PictureBox();
            this.denqt_se_poznava_ot_sutrinta_picbox = new System.Windows.Forms.PictureBox();
            this.toplata_staq_picbox = new System.Windows.Forms.PictureBox();
            this.help_btn = new System.Windows.Forms.PictureBox();
            this.name_panel.SuspendLayout();
            this.content_badge_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.game6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.game5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.game4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toi_plashta_picbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.denqt_se_poznava_ot_sutrinta_picbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toplata_staq_picbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.help_btn)).BeginInit();
            this.SuspendLayout();
            // 
            // badge_lbl
            // 
            this.badge_lbl.AutoSize = true;
            this.badge_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.badge_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(221)))), ((int)(((byte)(158)))));
            this.badge_lbl.Location = new System.Drawing.Point(267, 9);
            this.badge_lbl.Name = "badge_lbl";
            this.badge_lbl.Size = new System.Drawing.Size(653, 95);
            this.badge_lbl.TabIndex = 0;
            this.badge_lbl.Text = "Бадж Колекция";
            this.badge_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name_panel
            // 
            this.name_panel.Controls.Add(this.help_btn);
            this.name_panel.Controls.Add(this.badge_lbl);
            this.name_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.name_panel.Location = new System.Drawing.Point(0, 0);
            this.name_panel.Name = "name_panel";
            this.name_panel.Size = new System.Drawing.Size(1182, 119);
            this.name_panel.TabIndex = 1;
            // 
            // content_badge_panel
            // 
            this.content_badge_panel.Controls.Add(this.game6);
            this.content_badge_panel.Controls.Add(this.game5);
            this.content_badge_panel.Controls.Add(this.game4);
            this.content_badge_panel.Controls.Add(this.toi_plashta_picbox);
            this.content_badge_panel.Controls.Add(this.denqt_se_poznava_ot_sutrinta_picbox);
            this.content_badge_panel.Controls.Add(this.toplata_staq_picbox);
            this.content_badge_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.content_badge_panel.Location = new System.Drawing.Point(0, 119);
            this.content_badge_panel.Name = "content_badge_panel";
            this.content_badge_panel.Size = new System.Drawing.Size(1182, 584);
            this.content_badge_panel.TabIndex = 2;
            // 
            // game6
            // 
            this.game6.BackColor = System.Drawing.Color.Transparent;
            this.game6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.game6.Image = global::test_za_gabrovci.Properties.Resources.coming_soon;
            this.game6.Location = new System.Drawing.Point(805, 305);
            this.game6.Name = "game6";
            this.game6.Size = new System.Drawing.Size(326, 211);
            this.game6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.game6.TabIndex = 9;
            this.game6.TabStop = false;
            // 
            // game5
            // 
            this.game5.BackColor = System.Drawing.Color.Transparent;
            this.game5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.game5.Image = global::test_za_gabrovci.Properties.Resources.coming_soon;
            this.game5.Location = new System.Drawing.Point(415, 305);
            this.game5.Name = "game5";
            this.game5.Size = new System.Drawing.Size(326, 211);
            this.game5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.game5.TabIndex = 8;
            this.game5.TabStop = false;
            // 
            // game4
            // 
            this.game4.BackColor = System.Drawing.Color.SteelBlue;
            this.game4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.game4.Image = global::test_za_gabrovci.Properties.Resources.osnovanie_colored;
            this.game4.Location = new System.Drawing.Point(104, 305);
            this.game4.Name = "game4";
            this.game4.Size = new System.Drawing.Size(264, 211);
            this.game4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.game4.TabIndex = 7;
            this.game4.TabStop = false;
            this.game4.Click += new System.EventHandler(this.game4_Click);
            // 
            // toi_plashta_picbox
            // 
            this.toi_plashta_picbox.BackColor = System.Drawing.Color.SteelBlue;
            this.toi_plashta_picbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toi_plashta_picbox.Image = global::test_za_gabrovci.Properties.Resources.game3_colored;
            this.toi_plashta_picbox.Location = new System.Drawing.Point(774, 35);
            this.toi_plashta_picbox.Name = "toi_plashta_picbox";
            this.toi_plashta_picbox.Size = new System.Drawing.Size(374, 211);
            this.toi_plashta_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.toi_plashta_picbox.TabIndex = 6;
            this.toi_plashta_picbox.TabStop = false;
            this.toi_plashta_picbox.Click += new System.EventHandler(this.toi_plashta_picbox_Click);
            // 
            // denqt_se_poznava_ot_sutrinta_picbox
            // 
            this.denqt_se_poznava_ot_sutrinta_picbox.BackColor = System.Drawing.Color.SteelBlue;
            this.denqt_se_poznava_ot_sutrinta_picbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.denqt_se_poznava_ot_sutrinta_picbox.Image = global::test_za_gabrovci.Properties.Resources.game2_colored;
            this.denqt_se_poznava_ot_sutrinta_picbox.Location = new System.Drawing.Point(415, 35);
            this.denqt_se_poznava_ot_sutrinta_picbox.Name = "denqt_se_poznava_ot_sutrinta_picbox";
            this.denqt_se_poznava_ot_sutrinta_picbox.Size = new System.Drawing.Size(326, 211);
            this.denqt_se_poznava_ot_sutrinta_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.denqt_se_poznava_ot_sutrinta_picbox.TabIndex = 5;
            this.denqt_se_poznava_ot_sutrinta_picbox.TabStop = false;
            this.denqt_se_poznava_ot_sutrinta_picbox.Click += new System.EventHandler(this.denqt_se_poznava_ot_sutrinta_picbox_Click);
            // 
            // toplata_staq_picbox
            // 
            this.toplata_staq_picbox.BackColor = System.Drawing.Color.SteelBlue;
            this.toplata_staq_picbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toplata_staq_picbox.Image = global::test_za_gabrovci.Properties.Resources.game1_colored;
            this.toplata_staq_picbox.Location = new System.Drawing.Point(113, 35);
            this.toplata_staq_picbox.Name = "toplata_staq_picbox";
            this.toplata_staq_picbox.Size = new System.Drawing.Size(239, 211);
            this.toplata_staq_picbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.toplata_staq_picbox.TabIndex = 4;
            this.toplata_staq_picbox.TabStop = false;
            this.toplata_staq_picbox.Click += new System.EventHandler(this.toplata_staq_picbox_Click);
            // 
            // help_btn
            // 
            this.help_btn.BackColor = System.Drawing.Color.Transparent;
            this.help_btn.Image = global::test_za_gabrovci.Properties.Resources.help_btn_img;
            this.help_btn.Location = new System.Drawing.Point(1077, 12);
            this.help_btn.Name = "help_btn";
            this.help_btn.Size = new System.Drawing.Size(93, 93);
            this.help_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.help_btn.TabIndex = 5;
            this.help_btn.TabStop = false;
            this.help_btn.Click += new System.EventHandler(this.help_btn_Click);
            // 
            // badge_collection
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1182, 703);
            this.Controls.Add(this.content_badge_panel);
            this.Controls.Add(this.name_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "badge_collection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Бадж колекция";
            this.Load += new System.EventHandler(this.badge_collection_Load);
            this.name_panel.ResumeLayout(false);
            this.name_panel.PerformLayout();
            this.content_badge_panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.game6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.game5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.game4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toi_plashta_picbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.denqt_se_poznava_ot_sutrinta_picbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toplata_staq_picbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.help_btn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label badge_lbl;
        private System.Windows.Forms.Panel name_panel;
        private System.Windows.Forms.Panel content_badge_panel;
        private System.Windows.Forms.PictureBox help_btn;
        private System.Windows.Forms.PictureBox game6;
        private System.Windows.Forms.PictureBox game5;
        private System.Windows.Forms.PictureBox game4;
        private System.Windows.Forms.PictureBox toi_plashta_picbox;
        private System.Windows.Forms.PictureBox denqt_se_poznava_ot_sutrinta_picbox;
        private System.Windows.Forms.PictureBox toplata_staq_picbox;
    }
}

